package controller.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import model.member.MemberService;
import model.member.MemberVO;

@Controller 
public class MemberController {
	
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value="/login.do",method=RequestMethod.GET)
	public String loginPrint(@ModelAttribute("guest")MemberVO vo) { // �α��� get���, �Խ�Ʈ���̵� ��й�ȣ ����
		vo.setId("test");
		vo.setPassword("1234");
		return "login.jsp";
	}
	
	@RequestMapping(value="/login.do",method=RequestMethod.POST)
	public String login(HttpSession session, MemberVO vo, HttpServletResponse response) throws IOException { //�α��� post���
		if(vo.getId()==null || vo.getId().equals("")) {
			throw new IllegalArgumentException("로그인해라");
		}
		MemberVO data = memberService.getMember(vo);
		if(data!=null) {
			session.setAttribute("username", data);
			System.out.println(data);
			return "redirect:main.do";
		}
		else {
			return "login.jsp"; 
		}
	}
	
	@RequestMapping(value="/logout.do", method=RequestMethod.GET)
	public String logout(HttpSession session) { //�α׾ƿ�
		session.invalidate();
		return "login.jsp";
	}
	
	@RequestMapping("/updateMember.do")
	public String updateMember(MemberVO vo) {
		System.out.println(vo);
		memberService.updateMember(vo);
		return "redirect:main.do";
	}
	
	@RequestMapping("/deleteMember.do")
	public String deleteMember(HttpSession session, MemberVO vo) {
		session.invalidate();
		memberService.deleteMember(vo);
		return "main.do";
	}
	
	@RequestMapping("/mypage.do")
	public String selectOneMember(MemberVO vo, Model model) {
		System.out.println("mypage: "+vo);
		model.addAttribute("user", memberService.selectOneMember(vo));
		return "mypage.jsp";
	}
	
	@RequestMapping(value="/signup.do", method=RequestMethod.GET)
	public String getMemberPrint() {
		System.out.println("get방식으로 회원가입.do");
		return "signup.jsp";
	}

	@RequestMapping(value="/signup.do", method=RequestMethod.POST)
	public String getMember(MemberVO vo) {
		System.out.println("post방식으로 회원가입.do");
		memberService.insertMember(vo);
		return "login.jsp";
	}	
	@RequestMapping(value="/check.do", method=RequestMethod.GET)
	public int checkId(MemberVO vo) {
		System.out.println("아이디 중복체크");
		int cnt = memberService.checkId(vo);
		return cnt;
		
		
	}
	
}
