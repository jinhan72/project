	package controller.action;


import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import model.news.NewsService;
import model.news.NewsVO;
import model.paging.PageService;
import model.paging.PageVO;

@Controller
public class NewsController {
	
	@Autowired
	private NewsService newsService;
	@Autowired
	private PageService pageService;
	
	@RequestMapping("/main.do")
	public String getNewsList(NewsVO vo, Model model, PageVO pvo, @RequestParam(value="page",defaultValue="1")int page,@RequestParam(value="keyword",defaultValue="",required=false)String keyword) {
		pvo.setCurPage(page); // 현재 페이지
		pvo.setPerPage(8); // 페이지 게시물 수
		pvo.setPerPageSet(3); // 페이지 수 
		
		pvo = pageService.paging(pvo, vo);
		
		
		List<NewsVO> datas = newsService.getNewsList(vo, pvo);
		System.out.println("컨트롤러 getNewList지나감"+datas);
		model.addAttribute("datas", datas);
		model.addAttribute("paging", pvo);
		model.addAttribute("page", page);
		
		return "main.jsp";
	}
	
	@RequestMapping("/getNews.do")
	public String getNews(NewsVO vo, Model model) {
		NewsVO data = newsService.getNews(vo);
		model.addAttribute("data", data);
		System.out.println("선택한 뉴스 데이터 "+ newsService.getNews(vo));
		return "news.jsp";
	}
	
	@RequestMapping(value="/insertnews.do", method=RequestMethod.POST)
	public String insertNews(NewsVO vo) throws IllegalStateException, IOException {
		MultipartFile fileUpload = vo.getFileUpload();
		if(!fileUpload.isEmpty()) {
			String fileName = fileUpload.getOriginalFilename();
			System.out.println("파일 이름"+ fileName);
			String path = "C:\\Programing\\JAVA_1_kjh\\workspace\\Project.1.0.0\\src\\main\\webapp\\img\\";
			fileUpload.transferTo(new File(path+fileName));
			vo.setFiles("\\img\\"+fileName);
			System.out.println("insert컨트롤러: "+ vo);
			newsService.insertNews(vo);
		}
		return "redirect:main.do";
	}
	
	@RequestMapping(value="/insertnews.do", method=RequestMethod.GET)
	public String insertNewsprint() {
		return "insertnews.jsp";
	}
	
	@RequestMapping(value="/updateNews.do", method=RequestMethod.GET)
	public String updateNewsprint(NewsVO vo, Model model) {
		model.addAttribute("data", newsService.getNews(vo));
		return "insertnews.jsp";
	}
	
	@RequestMapping(value="/updateNews.do", method=RequestMethod.POST)
	public String updateNews(NewsVO vo) throws IllegalStateException, IOException {
		MultipartFile fileUpload = vo.getFileUpload();
			String path = "C:\\Programing\\JAVA_1_kjh\\workspace\\Project.1.0.0\\src\\main\\webapp\\img";
			if(!vo.getFileUpload().isEmpty()) { // 등록되어 있는 파일이 있을 때
				File preFile = new File(path+vo.getFiles());
				preFile.delete();
				String fileName = fileUpload.getOriginalFilename();
				fileUpload.transferTo(new File(path+fileName));
				System.out.println("이전파일"+vo.getFiles());
				vo.setFiles("\\img\\"+fileName);
			}

		newsService.updateNews(vo);
		return "redirect:main.do";
	}
	
	@RequestMapping(value="/deletNews.do", method=RequestMethod.GET)
	public String deleteNews(NewsVO vo) {
		newsService.deleteNews(vo);
		return "redirect:main.do";
	}

}
