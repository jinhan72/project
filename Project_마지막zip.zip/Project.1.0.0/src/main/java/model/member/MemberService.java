package model.member;

public interface MemberService {
	MemberVO getMember(MemberVO vo);
	void insertMember(MemberVO vo);
	void deleteMember(MemberVO vo);
	void updateMember(MemberVO vo);
	MemberVO selectOneMember(MemberVO vo);
	int checkId(MemberVO vo);
}
