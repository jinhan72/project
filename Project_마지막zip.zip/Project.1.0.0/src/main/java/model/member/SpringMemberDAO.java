package model.member;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

class MemberRowMapper implements RowMapper<MemberVO> {

	@Override
	public MemberVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		MemberVO data=new MemberVO();
		data.setId(rs.getString("id"));
		data.setPassword(rs.getString("password"));
		data.setName(rs.getString("name"));
		data.setEmail(rs.getString("email"));
		data.setAddress(rs.getString("address"));
		data.setRole(rs.getString("role"));
		return data;
	}

}

@Repository
public class SpringMemberDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final String getMemberSQL="select * from member where id=? and password=?";
	private final String insertMemberSQL="insert into member(id,password,name,email,address,role) values (?,?,?,?,?,?)";
	private final String deleteMemberSQL="delete member where id=?";
	private final String updateMemberSQL="update member set password=?,name=?,address=? where id=?";
	private final String selectOneMemberSQL = "select * from member where id=?";
	private final String checkID = "select * from client where id = ?";

	public MemberVO getMember(MemberVO vo) {
		System.out.println("jdbctemplate으로 getMember");
		Object[] args= { vo.getId(),vo.getPassword() };
		System.out.println(vo);
		return jdbcTemplate.queryForObject(getMemberSQL, args,new MemberRowMapper());
	}

	public void insertMember(MemberVO vo) {
		System.out.println("jdbctemplate으로 insertMember");
		Object[] args= { vo.getId(),vo.getPassword(),vo.getName(), vo.getEmail(), vo.getAddress(), vo.getRole() };
		jdbcTemplate.update(insertMemberSQL, args);
	}

	public void deleteMember(MemberVO vo) {
		System.out.println("jdbctemplate으로 deleteMember");
		jdbcTemplate.update(deleteMemberSQL, vo.getId());
	}

	public void updateMember(MemberVO vo) {
		System.out.println("jdbctemplate으로 updateMember");
		jdbcTemplate.update(updateMemberSQL,vo.getPassword(), vo.getName(), vo.getAddress(), vo.getId());
	}

	public MemberVO selectOneMember(MemberVO vo) {
		System.out.println("jdbcTemplate으로 selectoneMember");
		System.out.println(vo);	
		try {
			System.out.println("여기1");
			Object[] args = {vo.getId()};
			return jdbcTemplate.queryForObject(selectOneMemberSQL, args, new MemberRowMapper());	
		}catch(Exception e){
			System.out.println("여기2");
			return null;			
		}
	}

	public int checkId(MemberVO vo) {
		int cnt = 	jdbcTemplate.update(checkID, vo.getId());
		return cnt;

	}


}