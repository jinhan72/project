package model.paging;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import model.news.NewsVO;


class PageRowMapper implements RowMapper<PageVO>{

	@Override
	public PageVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		PageVO data = new PageVO();
		data.setTotal(rs.getInt(1));
		return data;
	}


}


@Repository
public class SpringPageDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final String selectAll = "select count(*) from news";
	private final String selectAllSearch = "select count(*) from new where keyword like?";

	public PageVO paging(PageVO pvo, NewsVO nvo) {
		if(nvo.getKeyword() ==null || nvo.getKeyword().equals("")) {
			pvo.setTotal((jdbcTemplate.queryForObject(selectAll, new PageRowMapper())).getTotal());
		}
		else {
			Object[] args = {"%"+nvo.getKeyword()+"%"};
			pvo.setTotal((jdbcTemplate.queryForObject(selectAllSearch,args, new PageRowMapper())).getTotal());
		}
		pvo.setLastPage((pvo.getTotal()-1)/pvo.getPerPage()+1);   //마지막 페이지 설정   
		pvo.setStart((pvo.getCurPage()-1)*pvo.getPerPage()+1);      //페이지에 보여줄 게시물 시작
		pvo.setEnd(pvo.getStart()+pvo.getPerPage());            //페이지에 보여줄 게시물 끝      



		pvo.setStartPage((pvo.getCurPage()-1)/pvo.getPerPageSet()*pvo.getPerPageSet()+1);   //목차 시작
		if(pvo.getStartPage() < 1) {      //시작페이지가 1보다 작을경우 1로 설정
			pvo.setStartPage(1);
		}

		pvo.setEndPage(pvo.getStartPage()+pvo.getPerPageSet()-1);                     //목차 끝
		if(pvo.getEndPage() > pvo.getLastPage()) {   //끝페이지가 마지막페이지보다 클경우 마지막페이지로 설정
			pvo.setEndPage(pvo.getLastPage());
		}


		return pvo;

	}
}
