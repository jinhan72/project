package model.paging;

import model.news.NewsVO;

public interface PageService {
	PageVO paging(PageVO pvo, NewsVO nvo);
}
