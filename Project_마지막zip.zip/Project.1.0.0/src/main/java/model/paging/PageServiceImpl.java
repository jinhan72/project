package model.paging;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.news.NewsVO;

@Service("pageService")
public class PageServiceImpl implements PageService {

	@Autowired
	private SpringPageDAO pageDAO;
	
	@Override
	public PageVO paging(PageVO pvo, NewsVO nvo) {
		return pageDAO.paging(pvo, nvo);
	}
	
}
