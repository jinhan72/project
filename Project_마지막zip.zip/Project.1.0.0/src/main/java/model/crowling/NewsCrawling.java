package model.crowling;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import model.common.JDBC;



public class NewsCrawling {
	public static void main(String[] args) throws SQLException {


		Connection conn = JDBC.getConnection();
		PreparedStatement pstmt = null;

		String url = "https://news.naver.com/main/list.naver?mode=LSD&mid=sec&sid1=001";
		String httpUrl = null;
		String title= null;
		String date = null;
		String files = null;
		String content = null;
		String writer = null;

		Document doc = null;


		try {
			doc = Jsoup.connect(url).get();


			Elements element = doc.select(".photo");
			for(int i=0; i<element.size(); i++) {
				httpUrl = element.get(i).select("a").attr("href");
				System.out.println("http 주소: "+httpUrl);

				Document doc2 = null;


				doc2 = Jsoup.connect(httpUrl).get();

				Elements el = doc2.select(".content");

			
				
				title = el.select(".article_info > h3").first().text();
				date = el.select(".t11").first().text();
				files = el.select(".end_photo_org > img").attr("src");
				content = el.select("._article_body_contents").get(0).text();
				writer = el.select(".byline > p").text();

				// 기자이름
				if(writer.length() == 0) {
					continue;
				}
				

				// 날짜 데이터 가공
				
					date = date.substring(0,10);
					date = date.replace(".", "-");
					date = date.replace(" ", "");
				

				// 이미지 데이터 가공
				files = files.substring(0, files.lastIndexOf("?"));		

				//
				/*if(content.length() > 1500) {
					continue;
				}*/

				System.out.println("+++++++++++++++++++++++++++++");

				System.out.println("타이틀: "+title);
				System.out.println("날짜: "+ date);
				System.out.println("이미지: "+ files);
				System.out.println("기사 내용: "+ content);
				System.out.println("기자: "+ writer);
				
				System.out.println("+++++++++++++++++++++++++++++");
//

			final String insertCrowlingSQL="insert into news(npk,writer,title,content,files,ndate) values((select nvl(max(npk),0)+1 from news),?,?,?,?,to_date(?,'YYYY-MM-DD'))"; //
			
			pstmt = conn.prepareStatement(insertCrowlingSQL);
			pstmt.setString(1, writer);
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			pstmt.setString(4, files);
			pstmt.setString(5, date);
			pstmt.executeUpdate();
		}
	
		}catch (IOException e) {
			e.printStackTrace();
		}finally {
			JDBC.close(conn, pstmt);
		}



	}


}


