package model.news;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import model.paging.PageVO;




class NewsRowMapper implements RowMapper<NewsVO> {

	@Override
	public NewsVO mapRow(ResultSet rs, int rowNum) throws SQLException {
		NewsVO data=new NewsVO();
		data.setNpk(rs.getInt("npk"));
		data.setTitle(rs.getString("title"));
		data.setWriter(rs.getString("writer"));
		data.setContent(rs.getString("content"));
	//	data.setNtype(rs.getNString("ntype"));
		data.setFiles(rs.getString("files"));
		data.setNdate(rs.getString("ndate"));
		return data;
	}

}


@Repository
public class SpringNewsDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private final String insertSQL="insert into news(npk,writer,title,content,files,ndate) values((select nvl(max(npk),0)+1 from news),?,?,?,?,?)"; // 뉴스등록
	private final String updateSQL="update news set files=?,writer=?,title=?,content=?,ndate=? where npk=?"; // 뉴스 업데이트
	private final String deleteSQL="delete news where npk=?";  // 뉴스 삭제
	private final String getNewsSQL="select * from news where npk=?";  // 뉴스 선택
	private final String selectAll = "select * from(select a.*, rownum as rnum from(select * from news order by npk asc) a where rownum < ?) where rnum >=?";			// 전체리스트
	private final String selectAllSearch = "select * from(select a.*, rownum as rnum from(select * from kim.news where title like '%'||?||'%' order by npk asc) a where rownum < ?) where rnum >=?";// 검색 시 전체 리스트


	public void insertNews(NewsVO vo) {
		System.out.println("jdbcTemplate으로 insert");
		Object[] args = {vo.getWriter(),vo.getTitle(),vo.getContent(),vo.getFiles(),vo.getNdate()};
		jdbcTemplate.update(insertSQL, args);
	}

	public void updateNews(NewsVO vo) {
		System.out.println("jdbcTemplate으로 update: " + vo);
		Object[] args = {vo.getFiles(),vo.getWriter(),vo.getTitle(),vo.getContent(),vo.getNdate(),vo.getNpk()};
		jdbcTemplate.update(updateSQL, args);
	}

	public void deleteNews(NewsVO vo) {
		System.out.println("jdbcTemplate으로 delete");
		jdbcTemplate.update(deleteSQL,vo.getNpk());
	}


	public List<NewsVO> getNewsList(NewsVO vo, PageVO pvo){
		if(vo.getKeyword()==null || vo.getKeyword().equals("")) {
			Object[] args = {pvo.getEnd(),pvo.getStart()};			
			return jdbcTemplate.query(selectAll, args, new NewsRowMapper());	

		}
		else {
			Object[] args = {vo.getKeyword(), pvo.getEnd(),pvo.getStart()};
			return jdbcTemplate.query(selectAllSearch, args,new NewsRowMapper());
		}

	}

	public NewsVO getNews(NewsVO vo) {
		System.out.println("jdbcTemplate으로 getBoard: " + vo);
		Object[] args= { vo.getNpk() };
		return jdbcTemplate.queryForObject(getNewsSQL,args,new NewsRowMapper());
	}






	/*public List<NewsVO> getNewsList(NewsVO vo) {
		System.out.println("jdbcTemplate으로 getBoardList");
		Object[] args= { vo.getKeyword() };
		if(vo.getCondition().equals("title")) {
			return jdbcTemplate.query(getNewsListSQL_TITLE,args,new NewsRowMapper());
		}
		else {
			return jdbcTemplate.query(getNewsListSQL_WRITER,args,new NewsRowMapper());
		}
	}*/


}
