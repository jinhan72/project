package model.news;

import java.util.List;

import model.paging.PageVO;


public interface NewsService {
	void insertNews(NewsVO vo);
	void updateNews(NewsVO vo);
	void deleteNews(NewsVO vo);
	List<NewsVO> getNewsList(NewsVO vo, PageVO pvo);
	NewsVO getNews(NewsVO vo);

}
