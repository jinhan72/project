package model.news;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.paging.PageVO;

@Service("newsService")
public class NewsServiceImpl implements NewsService{
	@Autowired
	private SpringNewsDAO newsDAO;
	
	@Override
	public void insertNews(NewsVO vo) {
		newsDAO.insertNews(vo);
	}

	@Override
	public void updateNews(NewsVO vo) {
		newsDAO.updateNews(vo);
		
	}

	@Override
	public void deleteNews(NewsVO vo) {
		newsDAO.deleteNews(vo);
		
	}

	@Override
	public List<NewsVO> getNewsList(NewsVO vo, PageVO pvo) {
		return newsDAO.getNewsList(vo, pvo);
	}

	@Override
	public NewsVO getNews(NewsVO vo) {
		return newsDAO.getNews(vo);
	}
	
}
