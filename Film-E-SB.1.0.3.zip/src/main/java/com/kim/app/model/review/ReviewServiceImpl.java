package com.kim.app.model.review;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.kim.app.model.movie.MovieVO;
import com.kim.app.model.page.PageVO;

@Service("reviewServiceImpl")
public class ReviewServiceImpl implements ReviewService {
	
	@Autowired
	private MybatisReviewDAO ReviewDAO;
	
	public ReviewVO r_selectDB_one(ReviewVO vo) {
		return ReviewDAO.rSelectOne(vo);
	}
	@Transactional
	public boolean r_insertDB(ReviewVO vo) {
		
		ReviewDAO.insert(vo);
		vo.setRatingavg(Math.round(ReviewDAO.starAVG(vo)*10)/10.0);
		ReviewDAO.mUpdate(vo);
		return true;
	}
	
	
	@Transactional
	public boolean r_deleteDB(ReviewVO vo) {
		ReviewDAO.delete(vo);
		vo.setRatingavg(Math.round(ReviewDAO.starAVG(vo)*10)/10.0);
		ReviewDAO.mUpdate(vo);
		return true;
	}

	public ArrayList<ReviewVO> r_selectDB_all(PageVO pvo) {
		return ReviewDAO.rSelectAll(pvo);
	}

}
