package com.kim.app.model.test;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Service("testServiceImpl")
@Repository
public class TestServiceImpl implements TestService {
	
	@Autowired
	private MybatisTestDAO testDAO;
	
	public HashMap<String, Object> search(){
		HashMap<String, Object> result = new HashMap<String, Object>();
		try {
			result.put("LIST", testDAO.search());
			result.put("CODE", "SUCCESS");
		} catch(Exception e) {
			e.printStackTrace();
			result.put("CODE", "ERROR");
			result.put("DATA", e.getMessage());
		}
		return result;
	}

	public boolean c_insert(TestVO vo) {
		System.out.println("서비스임플리 post방식 지나감"+ vo);
		return testDAO.insert(vo)>0;
	}

	public TestVO search_one(String id) {
		System.out.println("get one 방식으로 서비스임플리 지나감");
		TestVO cid = new TestVO();
		cid = testDAO.checkId(id);
		System.out.println(cid);
		return cid;
	}

	public boolean c_update(TestVO vo) {
		boolean result = true;
		testDAO.update(vo);
		return result;
	}

	public boolean c_delete(String id) {
		boolean result = true;
		testDAO.delete(id);
		return result;
		
	}

	public String getAccessToken (String authorize_code) {
        String access_Token = "";
        String refresh_Token = "";
        String reqURL = "https://kauth.kakao.com/oauth/token";
        
        try {
            URL url = new URL(reqURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            
            //    POST 요청을 위해 기본값이 false인 setDoOutput을 true로
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            
            //    POST 요청에 필요로 요구하는 파라미터 스트림을 통해 전송
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(conn.getOutputStream()));
            StringBuilder sb = new StringBuilder();
            sb.append("grant_type=authorization_code");
            sb.append("&client_id=943b3848940de9723adaef2077900681");
            sb.append("&redirect_uri=http://localhost:8090/oauth");
            sb.append("&code=" + authorize_code);
            bw.write(sb.toString());
            bw.flush();
            
            //    결과 코드가 200이라면 성공
            int responseCode = conn.getResponseCode();
            System.out.println("responseCode : " + responseCode);
 
            //    요청을 통해 얻은 JSON타입의 Response 메세지 읽어오기
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line = "";
            String result = "";
            
            while ((line = br.readLine()) != null) {
                result += line;
            }
            System.out.println("response body : " + result);
            
            //    Gson 라이브러리에 포함된 클래스로 JSON파싱 객체 생성
            JsonParser parser = new JsonParser();
            JsonElement element = parser.parse(result);
            
   /*         JsonObject properties = element.getAsJsonObject().get("properties").getAsJsonObject();
            JsonObject kakao_account = element.getAsJsonObject().get("kakao_account").getAsJsonObject();
            
            String nickname = properties.getAsJsonObject().get("nickname").getAsString();
            String email = kakao_account.getAsJsonObject().get("email").getAsString();
          
            System.out.println("이름"+nickname);
            System.out.println("이메일"+email);
            */
            access_Token = element.getAsJsonObject().get("access_token").getAsString();
            refresh_Token = element.getAsJsonObject().get("refresh_token").getAsString();
            
            System.out.println("access_token : " + access_Token);
            System.out.println("refresh_token : " + refresh_Token);
            
            br.close();
            bw.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } 
        
        return access_Token;
    }
	
}
