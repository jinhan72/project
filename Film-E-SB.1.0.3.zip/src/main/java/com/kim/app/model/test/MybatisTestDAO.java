package com.kim.app.model.test;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MybatisTestDAO {

	public ArrayList<HashMap<String, Object>> search();
	public int insert(TestVO vo);
	public TestVO checkId (String id);
	public int update(TestVO vo);
	public int delete(String id);
}




