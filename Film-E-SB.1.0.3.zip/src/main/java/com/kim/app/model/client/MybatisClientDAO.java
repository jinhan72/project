package com.kim.app.model.client;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface MybatisClientDAO {
	public int insert(ClientVO vo);
	public int update(ClientVO vo);
	public int delete(ClientVO vo);
	public int rUpdate(ClientVO vo);
	public ClientVO login(ClientVO vo);
	public ClientVO checkID(String id);
	
}




