package com.kim.app.model.movie;

import java.util.ArrayList;

import org.apache.ibatis.annotations.Mapper;

import com.kim.app.model.page.PageVO;

@Mapper
public interface MybatisMovieDAO {
	public ArrayList<MovieVO> selectAllm(PageVO vo);
	public ArrayList<MovieVO> selectAll(PageVO vo);
	public MovieVO selectOne(MovieVO vo);
	public int insert(MovieMultiVO vo);
	public int delete(MovieMultiVO vo);
	public int update(MovieMultiVO vo);
	public int rdelete(MovieMultiVO vo);
	public int count();
	public ArrayList<MovieVO> mpk();
	public ArrayList<MovieVO> selectRand();
}
