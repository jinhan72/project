package com.kim.app.model.test;

import java.util.HashMap;

public interface TestService {

	public HashMap<String, Object> search();
	public TestVO search_one(String id);
	public boolean c_insert(TestVO vo);
	public boolean c_update(TestVO vo);
	public boolean c_delete(String id);
	public String getAccessToken(String authorize_code);
}
