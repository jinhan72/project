package com.kim.app.model.client;

public interface ClientService {

	public boolean c_updateDB(ClientVO vo);
	public boolean c_deleteDB(ClientVO vo);
	public ClientVO login(ClientVO vo);
	public boolean c_insertDB(ClientVO vo);
	public ClientVO c_selectDB_one(ClientVO vo);
	public boolean checkID(String id);
	
}
