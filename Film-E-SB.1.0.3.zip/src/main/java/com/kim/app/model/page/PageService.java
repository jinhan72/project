package com.kim.app.model.page;

public interface PageService {
	public PageVO paging(PageVO vo);
	
}
