package com.kim.app.model.test;

import org.apache.ibatis.type.Alias;

@Alias("TestVO")
public class TestVO {
	private String id;
	private String pw;
	private String email;
	private String address;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "TestVO [id=" + id + ", pw=" + pw + ", email=" + email + ", address=" + address + "]";
	}

	
}
