package com.kim.app.controller.action;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kim.app.model.test.TestService;
import com.kim.app.model.test.TestVO;


@RestController // 이거 있음 리스폰스 바디 업성뙴
public class TestRestController {

	@Autowired
	private TestService testServiceImpl;
	
	
	@GetMapping("/get/client.do")
	public HashMap<String, Object> search(){
		System.out.println("get방식으로 조회");
		return testServiceImpl.search();	
	}
	
	@GetMapping("/get/getone.do/{id}")
	public TestVO getone(@PathVariable("id")String id) {
		return testServiceImpl.search_one(id);
		
	}
	

	@PostMapping("/post/Cinsert.do")
	public String cinsert(@RequestBody TestVO vo) {
		System.out.println("컨트롤러 post 로킹"+vo);
		ObjectMapper om = new ObjectMapper();
		
		testServiceImpl.c_insert(vo); 
	
		return "redirect:test.jsp";
		
	}
	
	@PutMapping("/put/cupdate.do")
	public String cupdate(@RequestBody TestVO vo) {
		System.out.println("컨트롤러put 로깅"+vo);
			
		testServiceImpl.c_update(vo);
		return "success";
	}
	
	@DeleteMapping("/delete/cdelete.do/{id}")
	public String cdelete(@PathVariable("id")String id) {
		
		testServiceImpl.c_delete(id);
		return "success";
		
	}
	
	@GetMapping("/oauth")
	public String kakaologin(@RequestParam("code") String code) {
		testServiceImpl.getAccessToken(code);
		return "test";
	}

	
	
}
