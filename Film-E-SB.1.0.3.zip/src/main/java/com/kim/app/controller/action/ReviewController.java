	package com.kim.app.controller.action;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.kim.app.model.movie.MovieService;
import com.kim.app.model.movie.MovieVO;
import com.kim.app.model.page.PageService;
import com.kim.app.model.page.PageVO;
import com.kim.app.model.review.ReviewService;
import com.kim.app.model.review.ReviewVO;

@Controller
@SessionAttributes("sessionID")
public class ReviewController {
	
	@Autowired
	private ReviewService reviewServiceImpl;
	
	@Autowired
	private PageService pageServiceImpl;
	
	@Autowired
	private MovieService movieServiceImpl;
	
	@ModelAttribute("sessionID")
	   public String ifNull() {
	      return null;
	   }
	
	
	@RequestMapping("/RselectAll.do")
	public String RselectAll(ReviewVO rVO, PageVO pVO, @RequestParam(value="page", defaultValue="1")int page, MovieVO rmVO, Model model, MovieVO  mVO, @ModelAttribute("sessionID")String id) {
		pVO.setCurPage(page);	
		pVO.setPerPage(8);		
		pVO.setPerPageSet(3);	
		pVO.setTable("review");
		
		rVO.setId(id);
		System.out.println("asdf1"+ mVO);
		System.out.println("asdf2"+ rVO);
		System.out.println("asdf3"+ pVO);
		System.out.println("asdf3"+ rmVO);
		
		mVO = movieServiceImpl.m_selectDB_one(mVO);
		rmVO = movieServiceImpl.m_selectDB_rand();
		rVO = reviewServiceImpl.r_selectDB_one(rVO);
		
		System.out.println("asdf"+ mVO);
		
		while(true) {
			rmVO = movieServiceImpl.m_selectDB_rand();
			if(!rmVO.getMpk().equals(mVO.getMpk())) {
				break;
			}
		}
		
	    pVO = pageServiceImpl.paging(pVO);

		
		ArrayList<ReviewVO> datas = reviewServiceImpl.r_selectDB_all(pVO);
		model.addAttribute("mdata", mVO);
		model.addAttribute("mrand", rmVO);
		model.addAttribute("paging", pVO);
		model.addAttribute("page", page);
		model.addAttribute("datas", datas);
		model.addAttribute("data", rVO);
		return "review";
		
	}
	
	@RequestMapping("/Rinsert.do")
	public String Rinsert(ReviewVO rVO,@ModelAttribute("sessionID")String id, Model model, @RequestParam("rating")Double rating, HttpServletResponse response) throws IOException {
		rVO.setId(id);
		
		if(rating != null) {
			rVO.setRating(rating);
		}
		else {
			rVO.setRating(3.0);
		}
		
		try {
				reviewServiceImpl.r_insertDB(rVO); 
				System.out.println("rin"+rVO);
				return "redirect:RselectAll.do?mpk="+ rVO.getMpk();
			
		} catch(Exception e){
			PrintWriter out = response.getWriter();
			response.setContentType("text/html; charset=UTF-8");
			out.println("<script>alert('���� ��� ����!');history.go(-1)</script>");
			return null;
		}
	}
		
		
	
	
	@RequestMapping("/Rdelete.do")
	public String Rdelete(HttpServletResponse response,Model model ,ReviewVO rVO, MovieVO mVO ) throws IOException {
	
		mVO = movieServiceImpl.m_selectDB_one(mVO);
	
		try {
				reviewServiceImpl.r_deleteDB(rVO);
				return "redirect:RselectAll.do?mpk="+ rVO.getMpk();
		} catch(Exception e) {
			e.printStackTrace();
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('���� ���� ����!');history.go(-1)</script>");
			return null;
		}
		
		
		
		
	}
	
}
