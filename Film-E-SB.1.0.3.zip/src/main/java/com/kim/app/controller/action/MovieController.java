package com.kim.app.controller.action;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.kim.app.model.movie.MovieMultiVO;
import com.kim.app.model.movie.MovieService;
import com.kim.app.model.movie.MovieVO;
import com.kim.app.model.page.PageService;
import com.kim.app.model.page.PageVO;

@Controller
public class MovieController {

	@Autowired
	private MovieService movieServiecImpl; 
	@Autowired
	private PageService pageServiceImpl;

	@RequestMapping("/Main.do")
	public String Main(PageVO vo, @RequestParam(value="page", defaultValue="1")int page, Model model) {
		vo.setCurPage(page);	
		vo.setPerPage(12);	
		vo.setPerPageSet(5);
		vo.setTable("movie");

		pageServiceImpl.paging(vo);
		model.addAttribute("datas", movieServiecImpl.m_selectDB_all_m(vo));
		model.addAttribute("paging",vo);
		model.addAttribute("page", page);
		return "main";

	}

	@RequestMapping("/Adminlist.do")
	public String Adminlist(PageVO pVO, @RequestParam(value="page", defaultValue="1")int page, Model model) {
		pVO.setCurPage(page);
		pVO.setPerPage(12);
		pVO.setPerPageSet(5);
		pVO.setTable("movie");

		pVO = pageServiceImpl.paging(pVO);
		
		model.addAttribute("datas", movieServiecImpl.m_selectDB_all(pVO));
		model.addAttribute("paging", pVO);
		model.addAttribute("page", page);
		model.addAttribute("search", pVO.getSearch());

		return "adminlist";

	}


	@RequestMapping("/Admin.do")
	public String Admin(MovieVO vo, Model model) {
		model.addAttribute("datas", movieServiecImpl.m_selectDB_one(vo));
		return "admin";

	}

	@RequestMapping("/Categories.do")
	public String Categories(@RequestParam(value="page", defaultValue="1")int page, PageVO pVO,Model model) {

		pVO.setCurPage(page);  
		pVO.setPerPage(8);    
		pVO.setPerPageSet(5); 
		pVO.setTable("movie");

		pVO = pageServiceImpl.paging(pVO);
		model.addAttribute("datas", movieServiecImpl.m_selectDB_all(pVO));
		model.addAttribute("paging", pVO);
		model.addAttribute("page", page);
		model.addAttribute("search", pVO.getSearch());
		model.addAttribute("mtype", pVO.getMtype());
		return "categories";

	}

	@RequestMapping("/Minsert.do")
	public String minsert(HttpServletRequest request, HttpServletResponse response, MovieMultiVO mVO) throws IOException {
		PrintWriter out = response.getWriter();

		String saveDir = request.getSession().getServletContext().getRealPath("img");
		MultipartFile fileupload = mVO.getFilename();

		if(!fileupload.isEmpty()) {
			mVO.setFiledb(UUID.randomUUID().toString().substring(7)+ fileupload.getOriginalFilename());
			fileupload.transferTo(new File(saveDir+"/"+mVO.getFiledb()));
		}

		if(movieServiecImpl.m_insertDB(mVO)) {
			return "redirect:Adminlist.do";
		}else {
			File file = new File(saveDir+"/"+ mVO.getFiledb());
			if(file.exists()) {
				file.delete();
			}
			response.setContentType("text/html; charset=UTF-8");
			out.println("<script>alert('게시물 등록 실패');history.go(-1)</script>");// 게시물 등록 실패 시 alert
			return null;
		}



	}

	@RequestMapping("/Mdelete.do")
	public String mdelete(HttpServletRequest request, HttpServletResponse response, MovieMultiVO mVO, MovieVO vo) throws IOException {
		PrintWriter out = response.getWriter();
		try {

			String saveDir = request.getSession().getServletContext().getRealPath("img");

			mVO.setFiledb(movieServiecImpl.m_selectDB_one(vo).getFilename().replace("img/", ""));

			if(movieServiecImpl.m_deleteDB(mVO)) {
				saveDir += "/"+ mVO.getFiledb();
				File file = new File(saveDir);
				if(file.exists()) {
					file.delete();
				}
				return "redirect:Adminlist.do";
			}
		}catch(Exception e) {
			response.setContentType("text/html; charset=UTF-8");
			out.println("<script>alert('게시물 삭제 실패');history.go(-1)</script>");// 게시물 등록 실패 시 alert
			
		}
		return null;

	}
	
	
	@RequestMapping("/Mupdate.do")
	public String mupdate(HttpServletRequest request, HttpServletResponse response, MovieMultiVO mVO) throws IOException {
		PrintWriter out = response.getWriter();
		String saveDir = request.getSession().getServletContext().getRealPath("img");
		MultipartFile fileupload = mVO.getFilename();
		MovieVO vo= new MovieVO();
		File file = null;
		
		vo.setMpk(mVO.getMpk());  
		
		
		String prefile = movieServiecImpl.m_selectDB_one(vo).getFilename().replace("img/", "");
		
		if(!fileupload.isEmpty()) {
			mVO.setFiledb(UUID.randomUUID().toString().substring(0,7)+ fileupload.getOriginalFilename());
			fileupload.transferTo(new File(saveDir+"/"+mVO.getFiledb()));
		}
		
		if(fileupload.isEmpty()) {
			mVO.setFiledb(prefile);
			if(movieServiecImpl.m_updateDB(mVO)) {
				return "redirect:Adminlist.do";
			}else {
				response.setContentType("text/html; charset=UTF-8");      
				out.println("<script>alert('업데이트 실패!');history.go(-1)</script>"); 
			}
		}else {
			if(movieServiecImpl.m_updateDB(mVO)) {
				saveDir += "/"+ prefile;
				file = new File(saveDir);
				file.delete();
				System.out.println("로깅"+prefile);
				return "redirect:Adminlist.do";
			}else {
				saveDir += "/"+mVO.getFiledb();
				file = new File(saveDir);
				if(file.exists()) {
					file.delete();
				}
				response.setContentType("text/html; charset=UTF-8");      
				out.println("<script>alert('업데이트 실패!');history.go(-1)</script>"); 
			}
		}
		
		
		
		return null;
		
	}
	
}
