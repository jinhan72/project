function ready(){}

$(document).ready(function(){
	common_ready();
});

function common_ready(){
	$("#btnSearch").click(function(){
		main_search();
	})
	$("#btnCreate").click(function(){
		main_cinsert();
	})
	$("#btnSearch2").click(function(){
		main_getone();
		
	})
	$("#btnUpdate").click(function(){
		main_update();
	})
	$("#btnDelete").click(function(){
		main_delete();
	})
	$("#sample6_execDaumPostcode").click(function(){
		sample6_execDaumPostcode();
	})
	$("#btnLogin").click(function(){
		main_login();
	})
	
}

function main_login(){
	console.log("kakao 로그인");
	var url = "";
	   url += "https://kauth.kakao.com/oauth/authorize";
	   url += "?client_id=";
	   // 키
	   url += "943b3848940de9723adaef2077900681";
	   url += "&redirect_uri=";
	   // 
	   url += "http://localhost:8090/oauth";  
	   url += "&response_type=";
	   url += "code"
	
	location.href= url;
}
	
	
function main_delete(){
	console.log('호이')
	var did= $("#did").val();
	$.ajax({
		type:'delete',
		url: '/delete/cdelete.do/'+did,
		dateType: 'json',
		success: function(result){
			alert("삭제 성공")
		},
		error: function(error){
			alert("삭제 실패")
		},
	})
}


function main_update(){
	console.log('ㅎㅇ')
	var uid = $("#uid").val();
	var upw = $("#upw").val();
	var uemail = $("#uemail").val();
	
	var uinsert = {"id": uid, "pw": upw, "email": uemail}
	console.log(uinsert)
	$.ajax({
		type: 'put',
		url: '/put/cupdate.do',
		data: JSON.stringify(uinsert),
		dataType: 'text',
		contentType: 'application/json',
		success:function(result){
			alert("수정 성공")
		},error:function(error){
			alert("수정 실패")
		},
		
	})
}



function main_search(){
	console.log('확인')
	$.ajax({
		type : 'get',
		url : '/get/client.do',
		dataType : 'json',
		success : function(result){
			if(result.CODE =="SUCCESS"){	
				console.log(result.LIST[0]);
				for(var i = 0; i < result.LIST.length; i++){
					$('#search').append('<div>' + result.LIST[i].ID +'</div>');
				}
			}else {
				alert(result.DATA);
			}
		},
		error : function(error){		
		},
		complete : function(xhr, textStatus){		
		}
	});
}


	function sample6_execDaumPostcode() {
		
		new daum.Postcode({
	        oncomplete: function(data) {
	            // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

	            // 각 주소의 노출 규칙에 따라 주소를 조합한다.
	            // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
	            var addr = ''; // 주소 변수
	            var extraAddr = ''; // 참고항목 변수

	            //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
	            if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
	                addr = data.roadAddress;
	            } else { // 사용자가 지번 주소를 선택했을 경우(J)
	                addr = data.jibunAddress;
	            }

	            // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
	            if(data.userSelectedType === 'R'){
	                // 법정동명이 있을 경우 추가한다. (법정리는 제외)
	                // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
	                if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
	                    extraAddr += data.bname;
	                }
	                // 건물명이 있고, 공동주택일 경우 추가한다.
	                if(data.buildingName !== '' && data.apartment === 'Y'){
	                    extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
	                }
	                // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
	                if(extraAddr !== ''){
	                    extraAddr = ' (' + extraAddr + ')';
	                }
	                // 조합된 참고항목을 해당 필드에 넣는다.
	                document.getElementById("sample6_extraAddress").value = extraAddr;
	            
	            } else {
	                document.getElementById("sample6_extraAddress").value = '';
	            }

	            // 우편번호와 주소 정보를 해당 필드에 넣는다.
	            document.getElementById('sample6_postcode').value = data.zonecode;
	            document.getElementById("sample6_address").value = addr;
	            // 커서를 상세주소 필드로 이동한다.
	            document.getElementById("sample6_detailAddress").focus();
	        }
	    }).open();
		
			}

	function main_cinsert(){
		var cid = $("#cid").val();
		var cpw = $("#cpw").val();
		var cemail = $("#cemail").val();
		var caddress = $("#sample6_address").val();
		var cdetailAddress = $("#sample6_detailAddress").val();
		var cextraAddress = $("#sample6_extraAddress").val();
		
		var c_address = caddress+cdetailAddress+cextraAddress;
		
		
		
		var cinsert = {"id": cid, "pw": cpw, "email": cemail, "address": c_address}
		
		console.log(cinsert)
		
		
		$.ajax({
			type: 'post',
			url: '/post/Cinsert.do',
			data: JSON.stringify(cinsert),
			dataType: 'text',
			contentType: 'application/json',
			success: function(data){
				alert("회원가입 완료")
			},
			error: function(error){
				alert("회원가입 실패")
			},
		})	
		console.log("확인")

			}


function main_getone(){
	console.log("확인")
	var pid = $("#id").val();
	$.ajax({
		type: 'get',
		url: '/get/getone.do/'+pid,
		success:function(cid){
			alert("조회 성공")
			console.log(cid)
			$('#search2').append('<div>' + cid.id +'</div>');
			
		},
		error: function(error){
			alert("조회 실패")
		},
	})
}










